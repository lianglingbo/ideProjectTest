#!/bin/bash
nohup ./bin/supervise -c ./conf/supervise/quickstart.conf >/dev/null 2>&1 &
