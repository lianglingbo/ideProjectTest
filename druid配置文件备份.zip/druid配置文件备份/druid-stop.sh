#!/bin/bash
./bin/service --down
