#!/bin/bash
nohup bin/tranquility server -configFile conf-quickstart/tranquility/devInf-server.json >/dev/null 2>&1 &
